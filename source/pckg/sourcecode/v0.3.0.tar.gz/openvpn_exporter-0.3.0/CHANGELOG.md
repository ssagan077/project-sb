## 0.2.1 / 2018-04-06

* [BUGFIX] CLIENT_LIST metrics collect fixed.

## 0.2 / 2017-04-14

* [FEATURE] Replace client and route counters by per-entry metrics.

## 0.1 / 2017-04-03

* [ENHANCEMENT] Initial release
