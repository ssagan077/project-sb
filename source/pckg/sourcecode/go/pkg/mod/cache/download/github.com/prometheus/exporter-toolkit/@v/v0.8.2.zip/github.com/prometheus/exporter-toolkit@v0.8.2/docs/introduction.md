# Introduction

The Prometheus Exporter Toolkit is a toolkit available to promote a common set
of practices when developing in the Prometheus ecosystem. It is written in
Golang.

This documentation is the end user configuration. Developers documentation can
be found on [pkg.go.dev](https://pkg.go.dev/github.com/prometheus/exporter-toolkit/).

* [Web configuration](web-configuration.md)
